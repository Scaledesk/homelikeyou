<?php defined('BASEPATH') or exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 * User: tushar
 * Date: 14/9/15
 * Time: 7:05 PM
 */

class Mdl_users extends CI_Model{
    const GUEST_ID =1; //may be needs to do it like it take it from database or to define user level as global constants later. It will be seen in future.
    private $user_id;
    private $user_name;
    private $password;
    private $role_id;
    private $roles_name;
    private $permissions_name;
    private $social_id;
    private $token;
    private $provider;

    /**
     * @param mixed $user_id
     */
    public function setUserId($user_id)
    {
        $this->user_id = $user_id;
    }


    public function __construct(){
        parent::__construct();
        $this->role_id=self::GUEST_ID;
    }

    /**
     * @param mixed $roles_name
     */
    public function setRolesName($roles_name)
    {
        $this->roles_name = $roles_name;
    }

    /**
     * @param mixed $permissions_name
     */
    public function setPermissionsName($permissions_name)
    {
        $this->permissions_name = $permissions_name;
    }

    /**
     *perform set data for class functions.
     */
    public function setData(){
        switch (func_get_arg(0)){
            case "register":    $this->setUserName(func_get_arg(1));
                                $this->setPassword(func_get_arg(2));
                                $this->setRoleId(func_get_arg(3));
                                break;
            case "checkUser":   /*echo '1.1';*/
                                $this->setUserName(func_get_arg(1));
                                $this->setPassword(func_get_arg(2));
                                /*echo '1.2';*/
                                break;
            case "setSessionData": { if($data=$this->db->where(array('hlu_users_permissions_username'=>func_get_arg(1)))->get('hlu_users_permissions')->result_array()){
                                        /*echo "<pre/>";
                                        print_r($data);die;*/

                                        $this->setUserId($data[0]['hlu_users_permissions_user_id']);
                                        $this->setUserName($data[0]['hlu_users_permissions_username']);
                                        $this->setRoleId($data[0]['hlu_users_permissions_user_role_id']);
                                        $this->setRolesName($data[0]['hlu_users_permissions_user_role']);
                                        foreach($data as $row){
                                            array_push($this->permissions_name,$row['hlu_users_permissions_user_permission']);
                                        }
                                        $this->getUserData();
                                        break;
                                    }else{
                                        $data=$this->db->where(array('hlu_users_username'=>func_get_arg(1)))->select('hlu_users_username,hlu_users_id,hlu_users_roles_id')->get('hlu_users')->result_array();
//                                        echo '<pre>';
//                                        print_r($data);
                                        $this->setUserID($data[0]['hlu_users_id']);
                                        $this->setUserName($data[0]['hlu_users_username']);
                                        $this->setRoleId($data[0]['hlu_users_roles_id']);
                                        //print_r($this->role_id);
                                        $role_name=$this->db->where(array('hlu_roles_id'=>$this->role_id))->select('hlu_roles_name')->get('hlu_roles')->result_array();
//                                        print_r($role_name);
                                        $this->setRolesName($role_name[0]['hlu_roles_name']);
                                        echo $this->roles_name;
//                die;
                                        $this->permissions_name=array();
                                    }
                            }
                                break;
            case "facebook_login":      {
                echo "1.1";
                                        $this->setUserName(func_get_arg(1));
                echo "1.2";
                                        $this->setSocialId(func_get_arg(2));
                echo "1.3";
                                        $this->setToken(func_get_arg(3));
                echo "1.4";
                                        $this->setProvider(func_get_arg(4));
                                        break;
            }
            case "is_Social":      {
                                        $this->setUserId(func_get_arg(1));
                                        $this->setProvider(func_get_arg(2));
                                        break;
            }
            default:            break;
        }

    }

    /**
     * @param mixed $provider
     */
    public function setProvider($provider)
    {
        $this->provider = $provider;
    }

    /**
     * @param mixed $social_id
     */
    public function setSocialId($social_id)
    {
        $this->social_id = $social_id;
    }

    /**
     * @param mixed $token
     */
    public function setToken($token)
    {
        $this->token = $token;
    }

    /**
     * @return mixed
     */
    public function getUserId()
    {
        return $this->user_id;
    }

    /**
     * @return mixed
     */
    public function getUserName()
    {
        return $this->user_name;
    }

    /**
     * @return mixed
     */
    public function getRoleId()
    {
        return $this->role_id;
    }

    /**
     * @return mixed
     */
    public function getRolesName()
    {
        return $this->roles_name;
    }

    /**
     * @return array
     */
    public function getPermissionsName()
    {
        return $this->permissions_name;
    }
    public function register(){
        echo "6";
        switch(func_get_arg(0)){
            case 'normal_registration':$this->_validate('normal_registration');
                $this->setPassword(password_hash($this->password,PASSWORD_DEFAULT));
                $data=[
                    'hlu_users_username'=>$this->user_name,
                    'hlu_users_password'=>$this->password,
                    'hlu_users_roles_id'=>$this->role_id
                ];
                if($this->db->insert('hlu_users',$data)){
                    return true;
                }
                return false;
                break;
            case 'social_registration':echo "7";$this->_validate('social_registration');echo "11";
                $data=[
                    'hlu_users_username'=>$this->user_name,
                    'hlu_users_social_id'=>$this->social_id,
                    'hlu_users_provider'=>$this->provider,
                    'hlu_users_roles_id'=>$this->role_id
                ];echo "12";
                if($this->db->insert('hlu_users',$data)){
                    echo "13";
                    return true;
                    echo "14";
                }
                return false;
                echo "16";
                break;
            default:break;
        }

    }

    /**
     * this checks user credentials on basis of user provided data
     * @return bool
     */
    public function checkUser(){
      //  echo '2.1';
        if($data=$this->db->where(array('hlu_users_username'=>$this->user_name))->select('hlu_users_password')->get('hlu_users')->result_array()){
        //    echo '2.2';
            /*print_r($data);*/
            if((password_verify($this->password,$data[0]['hlu_users_password'])))return true;
            return false;
        }
        /*echo "<pre/>";
        print_r($data);
        echo '2.3';*/
        return false;
    }

    /**
     * @param mixed $user_name
     */
    public function setUserName($user_name)
    {
        $this->user_name = $user_name;
    }

    /**
     * @param mixed $password
     */
    public function setPassword($password)
    {
        $this->password = $password;
    }

    /**
     * @param mixed $role_id
     */
    public function setRoleId($role_id)
    {
        $this->role_id = $role_id;
    }

    private function _validate()
    {echo "8";
        switch(func_get_arg(0)){
            case "normal_registration":$this->setPassword($this->security->xss_clean($this->password));
                $this->setUserName($this->security->xss_clean($this->user_name));
                $this->setRoleId($this->security->xss_clean($this->role_id));
                break;
            case "social_registration":echo "9";$this->setUserId($this->security->xss_clean($this->user_id));
                $this->setSocialId($this->security->xss_clean($this->social_id));
                $this->setToken($this->security->xss_clean($this->token));
                $this->setProvider($this->security->xss_clean($this->provider));
                echo "10";
                break;
            default: break;
        }

    }

    /**
     * return user data
     * @return array
     */
    public function getUserData()
    {
        return ['user_id'=>$this->getUserId(),'user_name'=>$this->getUserName(),
                    'user_role_id'=>$this->getRoleId(),'user_role_name'=>$this->getRolesName(),
                    'user_permissions'=>$this->getPermissionsName()
        ];
    }

    /*public function checkRegistarStatus(){
        if(!isSocial($this->user_id,$this->provider)){
        if($this->db->where(array('hlu_users_username'=>$this->user_id))->select('hlu_users_id')->get('hlu_users')){
            //set flash error message to inform user that he has already registered, trrough normal registration, try normal login or forgot password
        return true; //user already registered
            }
        }
        return false;
    }*/
    public function isSocialRegistered(){
        return $this->db->where(array('hlu_users_username'=>$this->user_name,'hlu_users_provider'=>$this->provider))->select('hlu_users_id')->get('hlu_users')->result_array()?true:false;
    }
    public function isNormalRegistered(){
        return $this->db->where(array('hlu_users_username'=>$this->user_id))->select('hlu_users_id')->get('hlu_users')->result_array()?true:false;
    }

}